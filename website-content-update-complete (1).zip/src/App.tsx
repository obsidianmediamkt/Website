import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  ArrowRight, 
  Instagram, 
  Facebook, 
  Mail, 
  Phone, 
  Check, 
  Zap, 
  Target, 
  Palette, 
  Globe, 
  Megaphone, 
  TrendingUp, 
  ChevronDown,
  Menu,
  X,
  Clock,
  Briefcase,
  Star,
  Users
} from "lucide-react";
import { cn } from "./utils/cn";

const LOGO_URL = "https://images.unsplash.com/photo-1740212727142-b052da24a350?q=80&w=2000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D";


const GlassContainer = ({ children, className }: { children: React.ReactNode, className?: string }) => (
  <div className={cn(
    "bg-black/40 backdrop-blur-[20px] border border-white/10 rounded-[2rem] shadow-2xl",
    className
  )}>
    {children}
  </div>
);

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "About", href: "#about" },
    { name: "Services", href: "#services" },
    { name: "Pricing", href: "#pricing" },
    { name: "Performance", href: "#performance" },
    { name: "Contact", href: "#contact" },
  ];

  return (
    <nav className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-500 py-4 px-6 md:px-12",
      isScrolled ? "bg-black/60 backdrop-blur-2xl border-b border-white/5 py-3 shadow-lg shadow-black/20" : "bg-transparent"
    )}>
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <a href="#" className="flex items-center gap-3">
          <img src={LOGO_URL} alt="Obsidian Media" className="h-10 md:h-12 w-auto object-contain rounded-sm" />
          <span className="text-xl font-bold tracking-tighter uppercase hidden md:block">
            Obsidian <span className="text-[#7f0019]">Media</span>
          </span>
        </a>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href}
              className="text-sm font-medium text-white/70 hover:text-white transition-colors duration-200"
            >
              {link.name}
            </a>
          ))}
          <a 
            href="#contact" 
            className="px-6 py-2.5 bg-[#7f0019] text-white text-sm font-semibold rounded-full hover:bg-[#a30021] transition-all duration-300 transform hover:scale-105 active:scale-95 shadow-lg shadow-[#7f0019]/20"
          >
            Get Started
          </a>
        </div>

        {/* Mobile Toggle */}
        <button 
          className="lg:hidden p-2 text-white"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-[#0a0a0a] border-b border-white/5 overflow-hidden"
          >
            <div className="flex flex-col p-6 gap-4">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href}
                  className="text-lg font-medium text-white/80"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {link.name}
                </a>
              ))}
              <a 
                href="#contact" 
                className="w-full py-4 bg-[#7f0019] text-center rounded-xl font-bold"
                onClick={() => setMobileMenuOpen(false)}
              >
                Get Started
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const FadeIn = ({ children, delay = 0, direction = "up", distance = 40 }: { children: React.ReactNode, delay?: number, direction?: "up" | "down" | "left" | "right", distance?: number }) => {
  const directions = {
    up: { y: distance },
    down: { y: -distance },
    left: { x: distance },
    right: { x: -distance },
  };

  return (
    <motion.div
      initial={{ opacity: 0, ...directions[direction] }}
      whileInView={{ opacity: 1, x: 0, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.8, delay, ease: [0.21, 0.47, 0.32, 0.98] }}
    >
      {children}
    </motion.div>
  );
};

const Hero = () => {
  return (
    <section className="relative min-screen h-[90vh] md:h-screen flex items-center justify-center pt-24 pb-20 px-6 overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-0 left-0 w-full h-full -z-10 bg-[#050505]">
        <div className="absolute top-[20%] left-1/2 -translate-x-1/2 w-[1000px] h-[400px] bg-[#7f0019]/10 rounded-[100%] blur-[120px]" />
        <div className="absolute bottom-[10%] left-[10%] w-[400px] h-[400px] bg-[#7f0019]/5 rounded-full blur-[120px]" />
      </div>

      <div className="max-w-6xl mx-auto text-center z-10 w-full">
        <FadeIn>
          <div className="inline-flex items-center gap-2 px-6 py-2 rounded-full border border-white/10 bg-white/5 backdrop-blur-2xl mb-12 shadow-lg">
            <span className="w-2 h-2 rounded-full bg-[#7f0019] animate-pulse shadow-[0_0_10px_#7f0019]" />
            <span className="text-[10px] md:text-xs font-bold tracking-widest uppercase text-white/70">Brand Builders • Content Creators • Growth Partners</span>
          </div>
        </FadeIn>

        <div className="space-y-12">
          <FadeIn delay={0.2}>
            <h1 className="text-6xl md:text-9xl lg:text-[11rem] font-extrabold leading-[0.9] tracking-tighter mb-4">
              We Create <br />
              <span className="obsidian-red-gradient">Difference.</span>
            </h1>
          </FadeIn>

          <FadeIn delay={0.4}>
            <p className="text-lg md:text-2xl text-white/50 max-w-3xl mx-auto font-medium leading-relaxed">
              We're not just a marketing agency — <span className="text-white">we're brand builders</span>. From viral content to long-term loyalty, we handle it all.
            </p>
          </FadeIn>

          <FadeIn delay={0.6}>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 pt-4">
              <a 
                href="#contact" 
                className="w-full sm:w-auto px-12 py-5 bg-[#7f0019] text-white rounded-full font-bold text-lg hover:bg-[#a30021] transition-all duration-300 shadow-2xl shadow-[#7f0019]/40 flex items-center justify-center gap-2 group"
              >
                Get Started <ArrowRight className="group-hover:translate-x-1 transition-transform" />
              </a>
              <a 
                href="#services" 
                className="w-full sm:w-auto px-12 py-5 bg-black/40 border border-white/10 text-white rounded-full font-bold text-lg hover:bg-white/10 transition-all duration-300 backdrop-blur-2xl flex items-center justify-center shadow-xl"
              >
                View Our Services
              </a>
            </div>
          </FadeIn>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="text-[10px] uppercase tracking-[0.3em] text-white/40 font-bold">Scroll</span>
        <div className="w-px h-12 bg-gradient-to-b from-white/20 to-transparent" />
      </motion.div>
    </section>
  );
};

const SectionHeading = ({ title, subtitle, centered = true }: { title: string, subtitle?: string, centered?: boolean }) => (
  <div className={cn("mb-24", centered ? "text-center" : "text-left")}>
    <FadeIn>
      <div className={cn("flex items-center gap-4 mb-8", centered ? "justify-center" : "justify-start")}>
        {!centered && <div className="w-12 h-1 bg-[#7f0019]" />}
        {centered && <div className="w-16 h-px bg-[#7f0019]/30" />}
        <span className="text-[10px] font-black tracking-[0.4em] uppercase text-[#7f0019]">{title}</span>
        {centered && <div className="w-16 h-px bg-[#7f0019]/30" />}
      </div>
    </FadeIn>
    {subtitle && (
      <FadeIn delay={0.1}>
        <h2 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter mt-4 leading-[0.9]">
          {subtitle}
        </h2>
      </FadeIn>
    )}
  </div>
);

const About = () => {
  const stats = [
    { label: "Founded", value: "2026", icon: <Clock /> },
    { label: "Model", value: "Hybrid", icon: <Globe /> },
    { label: "Focus", value: "ROI", icon: <Target /> },
    { label: "Strategy", value: "Data", icon: <TrendingUp /> },
  ];

  return (
    <section id="about" className="py-32 px-6 bg-[#0a0a0a] relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div className="order-2 lg:order-1">
            <SectionHeading 
              title="Introduction" 
              subtitle="We build brands for the digital age." 
              centered={false} 
            />
            <FadeIn delay={0.2} direction="right">
              <p className="text-lg text-white/50 mb-10 leading-relaxed font-medium">
                Obsidian Media began as an offline entity, depending on in-person meetings. Today, we've embraced a contemporary strategy — combining direct meetings with online interactions to enhance connections.
              </p>
              
              <div className="grid grid-cols-2 gap-4 md:gap-8">
                {stats.map((stat, i) => (
                  <GlassContainer key={i} className="p-8 border-white/5 bg-white/[0.02] hover:bg-white/[0.05] transition-colors group">
                    <div className="text-[#7f0019] mb-6 group-hover:scale-110 transition-transform">{stat.icon}</div>
                    <div className="text-3xl font-bold mb-2 tracking-tight">{stat.value}</div>
                    <div className="text-[10px] text-white/40 uppercase tracking-[0.2em] font-black">{stat.label}</div>
                  </GlassContainer>
                ))}
              </div>
            </FadeIn>
          </div>

          <div className="relative group order-1 lg:order-2">
            <FadeIn delay={0.3} direction="left">
              <div className="relative z-10 rounded-[3rem] overflow-hidden border border-white/10 shadow-2xl bg-black aspect-[4/3]">
                <img 
                  src="https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=2070&auto=format&fit=crop" 
                  alt="Team collaboration" 
                  className="w-full h-full object-cover grayscale opacity-60 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-1000"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-80" />
                
                {/* MATCHING PROMPT IMAGE: Vision Quote Card */}
                <div className="absolute bottom-6 left-6 right-6">
                  <GlassContainer className="p-8 md:p-12 bg-black/50 border-white/10 backdrop-blur-3xl">
                    <p className="text-2xl md:text-3xl font-bold italic mb-4 leading-tight">"We create difference."</p>
                    <div className="flex items-center gap-4">
                      <div className="w-8 h-px bg-white/20" />
                      <p className="text-sm md:text-base text-white/60 tracking-wide font-medium">The Obsidian Vision</p>
                    </div>
                  </GlassContainer>
                </div>
              </div>
              {/* Decorative Accent */}
              <div className="absolute -top-10 -right-10 w-80 h-80 bg-[#7f0019]/20 rounded-full blur-[100px] -z-10 group-hover:bg-[#7f0019]/30 transition-all duration-1000" />
            </FadeIn>
          </div>
        </div>
      </div>
    </section>
  );
};

const Vision = () => {
  const visions = [
    {
      id: "01",
      title: "Creative & Profitable",
      desc: "Make your business creative and unforgettable while ensuring profitability through strategic marketing strategies tailored specifically for our clients.",
      icon: <Palette className="w-8 h-8" />
    },
    {
      id: "02",
      title: "Captivate & Convert",
      desc: "Captivating the audience with engaging content that leaves a lasting impression — turning viewers into loyal customers.",
      icon: <Check className="w-8 h-8" />
    }
  ];

  return (
    <section className="py-32 px-6 bg-[#050505] relative overflow-hidden">
      <div className="max-w-7xl mx-auto text-center mb-20">
        <SectionHeading title="Our Vision" subtitle="Success Through Strategy" />
      </div>

      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-10">
        {visions.map((vision, i) => (
          <FadeIn key={i} delay={i * 0.2} direction={i === 0 ? "right" : "left"}>
            <GlassContainer className="group relative p-16 border-white/5 hover:border-white/10 hover:bg-white/[0.03] transition-all duration-700 h-full overflow-hidden">
              <div className="absolute top-0 right-0 p-12 text-9xl font-black text-white/[0.03] group-hover:text-[#7f0019]/10 transition-colors duration-700 select-none">
                {vision.id}
              </div>
              <div className="w-20 h-20 bg-[#7f0019]/10 rounded-3xl flex items-center justify-center text-[#7f0019] mb-12 group-hover:scale-110 group-hover:bg-[#7f0019]/20 transition-all duration-700 shadow-2xl shadow-[#7f0019]/10">
                {vision.icon}
              </div>
              <h3 className="text-3xl font-bold mb-8 group-hover:text-white transition-colors">Vision {vision.id} — {vision.title}</h3>
              <p className="text-lg text-white/40 leading-relaxed group-hover:text-white/60 transition-colors duration-700">
                {vision.desc}
              </p>
            </GlassContainer>
          </FadeIn>
        ))}
      </div>
    </section>
  );
};

const Services = () => {
  const services = [
    {
      title: "Content Creation",
      desc: "Strategic social media posts, reels & stories crafted with intention to engage, inform, and convert.",
      icon: Zap,
      tags: ["Reels", "Posts", "Stories", "Graphics"]
    },
    {
      title: "Social Media Management",
      desc: "We cultivate your optimal social presence through dedicated scheduling and community management.",
      icon: Briefcase,
      tags: ["Scheduling", "Engagement", "Analytics"]
    },
    {
      title: "Website Development",
      desc: "Engaging, interactive, and conversion-focused websites that effectively communicate your business value.",
      icon: Globe,
      tags: ["Responsive", "Modern UI", "Interactive"]
    },
    {
      title: "Article & Press Release",
      desc: "Get featured in credible Indian media channels and boost your brand's authority with budget-friendly rates.",
      icon: Megaphone,
      tags: ["PR", "Authority", "Newspapers"]
    }
  ];

  return (
    <section id="services" className="py-32 px-6 bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto">
        <SectionHeading title="Our Services" subtitle="Tailored Brand Solutions" />

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, i) => (
            <FadeIn key={i} delay={i * 0.1}>
              <GlassContainer className="group h-full p-10 border-white/5 hover:border-[#7f0019]/30 transition-all duration-700 relative overflow-hidden bg-white/[0.01]">
                <div className="w-16 h-16 bg-white/5 rounded-[1.5rem] flex items-center justify-center text-white/40 group-hover:bg-[#7f0019] group-hover:text-white transition-all duration-500 mb-10 shadow-2xl">
                  <service.icon size={32} />
                </div>
                <h3 className="text-2xl font-bold mb-6 group-hover:text-white transition-colors">{service.title}</h3>
                <p className="text-white/40 mb-10 leading-relaxed font-medium group-hover:text-white/60 transition-all duration-500">
                  {service.desc}
                </p>
                <div className="flex flex-wrap gap-3">
                  {service.tags.map((tag) => (
                    <span key={tag} className="px-4 py-1.5 bg-white/5 text-[10px] font-bold uppercase tracking-[0.15em] text-white/40 rounded-full border border-white/5 group-hover:border-white/20 transition-colors">
                      {tag}
                    </span>
                  ))}
                </div>
              </GlassContainer>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
};

const Pricing = () => {
  const plans = [
    {
      name: "Neo Package",
      badge: "Starter",
      price: "5,000",
      original: "10,000",
      features: [
        "4 Creative Posts",
        "4 Engaging Reels",
        "4 Engaging Stories",
        "Basic Branding Support"
      ],
      cta: "Choose Neo",
      highlight: false
    },
    {
      name: "Upscale Package",
      badge: "Growth",
      price: "7,000",
      original: "13,000",
      features: [
        "5 Creative Posts",
        "5 Engaging Reels",
        "7 Engaging Stories",
        "Detailed Analytic PDF",
        "Strategic Decision Insights"
      ],
      cta: "Choose Upscale",
      highlight: true
    },
    {
      name: "Upstand Package",
      badge: "Premium",
      price: "13,000",
      original: "18,000",
      features: [
        "13 Creative Posts",
        "7 Engaging Reels",
        "15 Engaging Stories",
        "Detailed Analytic PDF",
        "Full Strategic Support"
      ],
      cta: "Choose Upstand",
      highlight: false
    }
  ];

  return (
    <section id="pricing" className="py-32 px-6 bg-[#050505]">
      <div className="max-w-7xl mx-auto">
        <SectionHeading title="Pricing" subtitle="Select Your Growth Plan" />

        <div className="grid lg:grid-cols-3 gap-8">
          {plans.map((plan, i) => (
            <FadeIn key={i} delay={i * 0.1}>
              <GlassContainer className={cn(
                "relative p-12 transition-all duration-700 h-full flex flex-col group",
                plan.highlight 
                  ? "bg-[#7f0019]/10 border-[#7f0019]/40 shadow-2xl shadow-[#7f0019]/5 scale-105 z-10" 
                  : "border-white/5 hover:border-white/20 hover:bg-white/[0.03]"
              )}>
                {plan.highlight && (
                  <div className="absolute -top-5 left-1/2 -translate-x-1/2 px-6 py-2 bg-[#7f0019] text-white text-[10px] font-black uppercase tracking-[0.3em] rounded-full shadow-xl">
                    Most Popular
                  </div>
                )}
                
                <div className="mb-12">
                  <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 mb-3 block">{plan.badge}</span>
                  <h3 className="text-3xl font-extrabold mb-6 tracking-tight group-hover:text-[#7f0019] transition-colors">{plan.name}</h3>
                  <div className="flex items-baseline gap-4">
                    <span className="text-5xl font-black">₹{plan.price}</span>
                    <span className="text-white/20 line-through text-lg font-bold">₹{plan.original}</span>
                    <span className="text-white/30 text-xs font-black uppercase tracking-widest">/mo</span>
                  </div>
                </div>

                <div className="space-y-6 mb-12 flex-grow">
                  {plan.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-4 group/item">
                      <div className={cn(
                        "w-6 h-6 rounded-full flex items-center justify-center shrink-0 transition-all",
                        plan.highlight ? "bg-[#7f0019] text-white" : "bg-white/10 text-white/40 group-hover/item:bg-[#7f0019]/20 group-hover/item:text-[#7f0019]"
                      )}>
                        <Check size={14} strokeWidth={3} />
                      </div>
                      <span className="text-white/50 text-base font-medium group-hover/item:text-white transition-colors">{feature}</span>
                    </div>
                  ))}
                </div>

                <a 
                  href="#contact" 
                  className={cn(
                    "w-full py-6 rounded-2xl font-black uppercase tracking-[0.1em] text-sm text-center transition-all duration-500",
                    plan.highlight 
                      ? "bg-[#7f0019] text-white hover:bg-[#a30021] shadow-2xl shadow-[#7f0019]/20" 
                      : "bg-white/5 text-white border border-white/10 hover:bg-white/10"
                  )}
                >
                  {plan.cta}
                </a>
              </GlassContainer>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
};

const PerformanceMarketing = () => {
  const points = [
    "Trend-based campaign strategy",
    "Data-driven audience targeting",
    "Local market domination",
    "Multi-platform ad management",
    "Continuous ROI optimization"
  ];

  return (
    <section id="performance" className="py-32 px-6 bg-[#0a0a0a] relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-1/2 right-0 -translate-y-1/2 w-[800px] h-[400px] bg-[#7f0019]/5 rounded-full blur-[150px] -z-10" />

      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <FadeIn direction="right">
            <SectionHeading 
              title="Performance Marketing" 
              subtitle="Drive Growth Through Data" 
              centered={false} 
            />
            <p className="text-xl text-white/40 mb-12 leading-relaxed font-medium">
              We leverage trending topics and deep insights to craft campaigns that deliver a better ROI than anticipated. Our strategies focus on your local audience and outpacing competition on every platform.
            </p>
            <div className="space-y-6 mb-12">
              {points.map((point, i) => (
                <div key={i} className="flex items-center gap-5 group">
                  <div className="w-7 h-7 rounded-xl bg-[#7f0019]/10 border border-[#7f0019]/20 flex items-center justify-center text-[#7f0019] group-hover:scale-110 transition-transform">
                    <Check size={16} strokeWidth={3} />
                  </div>
                  <span className="font-bold text-lg text-white/70 group-hover:text-white transition-colors">{point}</span>
                </div>
              ))}
            </div>
            <a 
              href="#contact" 
              className="inline-flex items-center gap-4 px-10 py-5 bg-[#7f0019] text-white rounded-3xl font-black uppercase tracking-[0.1em] text-sm hover:bg-[#a30021] transition-all group shadow-2xl shadow-[#7f0019]/20"
            >
              Start Your Campaign <ArrowRight className="group-hover:translate-x-2 transition-transform" />
            </a>
          </FadeIn>

          <FadeIn direction="left" delay={0.2}>
            <div className="grid grid-cols-2 gap-6">
              {[
                { label: "ROI Focused", icon: TrendingUp },
                { label: "Data Driven", icon: Target },
                { label: "Ad Experts", icon: Star },
                { label: "Growth", icon: Users }
              ].map((item, i) => (
                <GlassContainer key={i} className="p-12 border-white/5 flex flex-col items-center text-center group hover:bg-[#7f0019]/5 hover:border-[#7f0019]/30 transition-all duration-700">
                  <div className="text-[#7f0019] mb-8 group-hover:scale-110 transition-transform duration-500">
                    <item.icon size={48} strokeWidth={1.5} />
                  </div>
                  <span className="font-black text-xs uppercase tracking-[0.3em] text-white/40 group-hover:text-white transition-colors">{item.label}</span>
                </GlassContainer>
              ))}
            </div>
          </FadeIn>
        </div>
      </div>
    </section>
  );
};

const WhyChooseUs = () => {
  const reasons = [
    { title: "Data-Driven Strategy", desc: "Every decision backed by analytics", icon: Target },
    { title: "Creative Excellence", desc: "Scroll-stopping content that converts", icon: Palette },
    { title: "Budget-Friendly", desc: "Premium quality at affordable rates", icon: Zap },
    { title: "Dedicated Support", desc: "Your brand is our priority", icon: Users },
    { title: "Proven ROI", desc: "Campaigns designed for measurable growth", icon: TrendingUp },
    { title: "Quick Turnaround", desc: "Fast delivery without compromising quality", icon: Clock },
  ];

  return (
    <section className="py-32 px-6 bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto">
        <SectionHeading title="Why Choose Us" subtitle="Your Strategic Advantage" />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reasons.map((reason, i) => (
            <FadeIn key={i} delay={i * 0.1}>
              <GlassContainer className="p-10 border-white/5 bg-white/[0.01] hover:bg-white/[0.03] transition-all duration-700 flex flex-col items-center text-center group">
                <div className="w-20 h-20 bg-[#7f0019]/5 rounded-3xl flex items-center justify-center text-[#7f0019] mb-10 group-hover:scale-110 group-hover:bg-[#7f0019]/20 transition-all duration-700 border border-[#7f0019]/10">
                  <reason.icon size={32} />
                </div>
                <h3 className="text-2xl font-bold mb-4 tracking-tight group-hover:text-white transition-colors">{reason.title}</h3>
                <p className="text-white/40 font-medium group-hover:text-white/60 transition-colors">{reason.desc}</p>
              </GlassContainer>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
};

const FAQ = () => {
  const faqs = [
    {
      q: "What platforms do you manage?",
      a: "We manage Instagram, Facebook, and other major social media platforms. We also handle website development and press release distribution across Indian media channels."
    },
    {
      q: "How long does it take to see results?",
      a: "While organic growth takes time, most clients begin seeing noticeable engagement improvements within the first month. Performance marketing campaigns can deliver results from day one."
    },
    {
      q: "Can I customize a package?",
      a: "Absolutely! Our listed packages are starting points. Contact us to discuss a custom plan tailored to your specific business needs."
    },
    {
      q: "Do you require a long-term contract?",
      a: "We believe in earning your trust through results, not contracts. Our packages are month-to-month, giving you complete flexibility."
    },
    {
      q: "Do you provide analytics and reports?",
      a: "Yes! Our Upscale and Upstand packages include detailed analytic PDFs and strategic insights. We believe in full transparency with our clients."
    }
  ];

  const [active, setActive] = useState<number | null>(0);

  return (
    <section className="py-32 px-6 bg-[#050505]">
      <div className="max-w-4xl mx-auto">
        <SectionHeading title="FAQ" subtitle="Common Questions" />
        
        <div className="space-y-6">
          {faqs.map((faq, i) => (
            <FadeIn key={i} delay={i * 0.1}>
              <GlassContainer 
                className={cn(
                  "border-white/5 transition-all duration-500 overflow-hidden",
                  active === i ? "bg-white/[0.05] border-[#7f0019]/20 shadow-xl" : "bg-white/[0.01]"
                )}
              >
                <button 
                  onClick={() => setActive(active === i ? null : i)}
                  className="w-full p-8 md:p-10 flex items-center justify-between text-left group"
                >
                  <span className={cn(
                    "text-xl font-bold transition-colors duration-500",
                    active === i ? "text-[#7f0019]" : "text-white group-hover:text-white/80"
                  )}>{faq.q}</span>
                  <div className={cn(
                    "transition-all duration-500 w-10 h-10 rounded-full flex items-center justify-center",
                    active === i ? "bg-[#7f0019] text-white rotate-180" : "bg-white/5 text-white/40 group-hover:bg-white/10"
                  )}>
                    <ChevronDown size={20} />
                  </div>
                </button>
                <AnimatePresence>
                  {active === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="p-8 md:p-10 pt-0 text-white/40 text-lg leading-relaxed font-medium">
                        {faq.a}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </GlassContainer>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
};

const Contact = () => {
  return (
    <section id="contact" className="py-32 px-6 bg-[#0a0a0a] relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-24 items-center">
          <FadeIn direction="right">
            <SectionHeading 
              title="Get In Touch" 
              subtitle="Let's build something unforgettable." 
              centered={false} 
            />
            <div className="space-y-12 mt-12">
              <div className="flex items-center gap-8 group">
                <div className="w-16 h-16 bg-[#7f0019]/10 rounded-[1.5rem] border border-[#7f0019]/20 flex items-center justify-center text-[#7f0019] shrink-0 group-hover:bg-[#7f0019] group-hover:text-white transition-all duration-500">
                  <Phone size={28} />
                </div>
                <div>
                  <p className="text-white/40 text-[10px] font-black uppercase tracking-[0.3em] mb-2">Call Us</p>
                  <p className="text-3xl font-bold tracking-tight">+91 8087473770</p>
                </div>
              </div>
              <div className="flex items-center gap-8 group">
                <div className="w-16 h-16 bg-[#7f0019]/10 rounded-[1.5rem] border border-[#7f0019]/20 flex items-center justify-center text-[#7f0019] shrink-0 group-hover:bg-[#7f0019] group-hover:text-white transition-all duration-500">
                  <Mail size={28} />
                </div>
                <div>
                  <p className="text-white/40 text-[10px] font-black uppercase tracking-[0.3em] mb-2">Email Us</p>
                  <p className="text-3xl font-bold tracking-tight">contact@obsidianmedia.in</p>
                </div>
              </div>
              <div className="flex items-center gap-8 group">
                <div className="w-16 h-16 bg-[#7f0019]/10 rounded-[1.5rem] border border-[#7f0019]/20 flex items-center justify-center text-[#7f0019] shrink-0 group-hover:bg-[#7f0019] group-hover:text-white transition-all duration-500">
                  <Globe size={28} />
                </div>
                <div>
                  <p className="text-white/40 text-[10px] font-black uppercase tracking-[0.3em] mb-2">Location</p>
                  <p className="text-3xl font-bold tracking-tight">India</p>
                </div>
              </div>
            </div>

            <div className="flex gap-6 mt-20">
              {[Instagram, Facebook].map((Icon, i) => (
                <a 
                  key={i} 
                  href="#" 
                  className="w-16 h-16 bg-white/[0.03] border border-white/10 rounded-2xl flex items-center justify-center text-white/40 hover:text-white hover:bg-[#7f0019] hover:border-[#7f0019] transition-all duration-500 shadow-2xl"
                >
                  <Icon size={24} />
                </a>
              ))}
            </div>
          </FadeIn>

          <FadeIn direction="left" delay={0.2}>
            <GlassContainer className="p-12 md:p-16 border-white/5 relative overflow-hidden bg-white/[0.01]">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#7f0019] to-transparent" />
              <form className="space-y-10">
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.3em] ml-2">Full Name</label>
                    <input type="text" className="w-full px-8 py-5 bg-black/40 border border-white/10 rounded-2xl focus:border-[#7f0019]/50 focus:bg-black/60 outline-none transition-all font-medium text-white placeholder:text-white/10" placeholder="John Doe" />
                  </div>
                  <div className="space-y-3">
                    <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.3em] ml-2">Email Address</label>
                    <input type="email" className="w-full px-8 py-5 bg-black/40 border border-white/10 rounded-2xl focus:border-[#7f0019]/50 focus:bg-black/60 outline-none transition-all font-medium text-white placeholder:text-white/10" placeholder="john@company.com" />
                  </div>
                </div>
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.3em] ml-2">Service Interested In</label>
                  <div className="relative">
                    <select className="w-full px-8 py-5 bg-black/40 border border-white/10 rounded-2xl focus:border-[#7f0019]/50 focus:bg-black/60 outline-none transition-all appearance-none cursor-pointer font-medium text-white">
                      <option className="bg-[#050505]">Content Creation</option>
                      <option className="bg-[#050505]">Social Media Management</option>
                      <option className="bg-[#050505]">Performance Marketing</option>
                      <option className="bg-[#050505]">Website Development</option>
                      <option className="bg-[#050505]">Article Posting / PR</option>
                      <option className="bg-[#050505]">Other</option>
                    </select>
                    <ChevronDown className="absolute right-6 top-1/2 -translate-y-1/2 text-white/20 pointer-events-none" size={20} />
                  </div>
                </div>
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.3em] ml-2">Message</label>
                  <textarea rows={5} className="w-full px-8 py-5 bg-black/40 border border-white/10 rounded-2xl focus:border-[#7f0019]/50 focus:bg-black/60 outline-none transition-all resize-none font-medium text-white placeholder:text-white/10" placeholder="Tell us about your project..." />
                </div>
                <button className="w-full py-6 bg-[#7f0019] text-white rounded-2xl font-black uppercase tracking-[0.2em] text-sm hover:bg-[#a30021] transition-all duration-500 shadow-2xl shadow-[#7f0019]/30 transform active:scale-[0.98]">
                  Send Message
                </button>
              </form>
            </GlassContainer>
          </FadeIn>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="py-32 px-6 bg-black border-t border-white/5">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-16 items-start">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-4 mb-10">
              <img src={LOGO_URL} alt="Obsidian Media" className="h-14 w-auto object-contain rounded-md" />
              <span className="text-2xl font-black tracking-tighter uppercase">Obsidian <span className="text-[#7f0019]">Media</span></span>
            </div>
            <p className="text-white/30 max-w-sm leading-loose font-medium text-lg">
              We create difference. We are not just a marketing agency — we are brand builders.
            </p>
          </div>
          
          <div>
            <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-white/50 mb-10">Quick Links</h4>
            <div className="flex flex-col gap-5">
              {["About", "Services", "Pricing", "Performance", "FAQ", "Contact"].map((link) => (
                <a key={link} href={`#${link.toLowerCase()}`} className="text-white/40 hover:text-[#7f0019] transition-all font-bold tracking-tight">{link}</a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-white/50 mb-10">Newsletter</h4>
            <p className="text-white/30 mb-8 text-base font-medium">Join 2,000+ brands building the future.</p>
            <GlassContainer className="relative bg-white/[0.02] border-white/10 rounded-2xl overflow-hidden p-1">
              <input type="email" placeholder="Enter email..." className="w-full px-6 py-4 bg-transparent outline-none font-medium text-white placeholder:text-white/10" />
              <button className="absolute right-1 top-1 bottom-1 px-6 bg-[#7f0019] rounded-xl text-[10px] font-black uppercase tracking-[0.2em] shadow-xl hover:bg-[#a30021] transition-all">Join</button>
            </GlassContainer>
          </div>
        </div>

        <div className="mt-32 pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8">
          <p className="text-white/20 text-xs font-bold tracking-widest uppercase">© 2026 Obsidian Media • India</p>
          <div className="flex gap-12">
            <a href="#" className="text-white/20 text-xs font-black uppercase tracking-widest hover:text-white transition-colors">Privacy</a>
            <a href="#" className="text-white/20 text-xs font-black uppercase tracking-widest hover:text-white transition-colors">Terms</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export function App() {
  return (
    <div className="relative min-h-screen bg-[#050505] selection:bg-[#7f0019]/30 selection:text-white">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Vision />
        <Services />
        <PerformanceMarketing />
        <Pricing />
        <WhyChooseUs />
        <FAQ />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
